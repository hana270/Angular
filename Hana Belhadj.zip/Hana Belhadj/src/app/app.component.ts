import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { VoitureServiceService } from './voiture-service.service';
import { Voiture } from '../model/voiture';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  voitures!: Voiture[];
  voitureForm!: FormGroup;
  editingId: number | null = null;
  private subscriptions: Subscription[] = [];

  constructor(private voitureService: VoitureServiceService, private fb: FormBuilder) {
    this.voitureForm = this.fb.group({
      titre: ['', Validators.required],
      description: ['', Validators.required],
      dateC: ['', Validators.required]    
    });
  }

  ngOnInit(): void {
    this.refreshVoitures();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
  }

  private refreshVoitures(): void {
    this.subscriptions.push(
      this.voitureService.getVoitures().subscribe(
        (response: Voiture[]) => this.voitures = response,
        (error: any) => console.error('Error fetching Voitures:', error)
      )
    );
  }

  addVoiture(): void {
    const newVoiture = this.voitureForm.value as Voiture;
    this.voitureService.addVoiture(newVoiture).subscribe(
      (addedVoiture: Voiture) => {
        this.voitures.push(addedVoiture);
        this.voitureForm.reset();

      },
      (error: any) => console.error('Error adding Voiture:', error)
    );
  }


  updateVoiture(voiture: Voiture | number): void {
     }




     
     deleteVoiture(voitureId: number): void {
      this.voitureService.deleteVoiture(voitureId).subscribe(
        () => {
          this.voitures = this.voitures.filter(v=>v.id !== voitureId);
        }
      );
    }
}
