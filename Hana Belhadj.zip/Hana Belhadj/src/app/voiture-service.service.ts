import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Voiture } from '../model/voiture';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class VoitureServiceService {
  
  
  private baseUrl = 'http://localhost:3000/voitures';

  constructor(private http: HttpClient) { }

  public getVoitures(): Observable<Voiture[]> {
    return this.http.get<Voiture[]>(this.baseUrl);
  }
  
  public addVoiture(voiture: Voiture): Observable<Voiture> {
    return this.http.post<Voiture>(this.baseUrl, voiture);
  }




  



  public deleteVoiture(voitureId: number): Observable<void> {
    const url = `${this.baseUrl}/${voitureId}`;

    return this.http.delete<void>(url);
  }


}
