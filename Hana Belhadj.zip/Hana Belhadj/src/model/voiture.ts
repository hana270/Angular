export class Voiture {
    public id: number;
    public titre: string;
    public description: string;
    public dateC: Date;
    
    constructor(id:number,titre: string, description: string,dateC: Date) { 
    this.id = id;
    this.titre = titre;
    this.description = description;
    this.dateC =dateC;
   
}
    }